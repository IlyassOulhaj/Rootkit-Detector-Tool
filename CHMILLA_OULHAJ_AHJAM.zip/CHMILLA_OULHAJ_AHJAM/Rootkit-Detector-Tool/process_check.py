import os
import subprocess
import sys
import time

def get_visible_pids():
    visible_pids = set()
    try:
        output = subprocess.check_output(['ps', '-e']).decode('utf-8')
        
        for line in output.splitlines()[1:]:
            parts = line.split()
            if parts:
                pid = int(parts[0])
                visible_pids.add(pid)
    except Exception as e:
        print(f"[ERREUR] Impossible de lancer ps : {e}")
    
    return visible_pids

def get_hidden_pids_bruteforce():
    real_pids = set()
    
    try:
        with open('/proc/sys/kernel/pid_max', 'r') as f:
            max_pid = int(f.read())
    except:
        max_pid = 32768

    print(f"[*] Scan de 1 à {max_pid} PIDs en cours... (patience)")

    for pid in range(1, max_pid + 1):
        try:
            os.kill(pid, 0)
            real_pids.add(pid)
        except ProcessLookupError:
            pass
        except PermissionError:
            real_pids.add(pid)
        except OSError:
            pass

    return real_pids

def scan_process():
    print("--- Démarrage du Module Processus (Ilyass) ---")
    
    print("[*] Lecture de la liste 'ps'...")
    visible = get_visible_pids()
    
    print("[*] Scan Brute-force en cours...")
    real = get_hidden_pids_bruteforce()

    suspects = real - visible
    
    if not suspects:
        print("\n[OK] Aucun processus caché détecté.")
        return False

    print(f"    -> {len(suspects)} candidats suspects trouvés. Vérification...")

    time.sleep(1) 
    visible_update = get_visible_pids()
    
    confirmed_hidden = suspects - visible_update

    if confirmed_hidden:
        print(f"\n[!] ALERTE : {len(confirmed_hidden)} VRAIS processus cachés détectés !")
        
        for pid in confirmed_hidden:
            try:
                with open(f'/proc/{pid}/comm', 'r') as f:
                    name = f.read().strip()
                print(f"    - PID {pid}: {name} (CACHÉ)")
            except:
                print(f"    - PID {pid}: ???")
        return True
    else:
        print("\n[OK] Fausse alerte (c'était juste des processus démarrés pendant le scan).")
        return False

if __name__ == "__main__":
    scan_process()