import sys
import time
import process_check
import file_check
import net_check 

def run_full_scan():
    print("========================================")
    print("      LINUX ROOTKIT DETECTOR v1.0       ")
    print("========================================")
    
    detections = 0

    print("\n[+] Launching Process Scan (Module: Ilyass)...")
    time.sleep(1)
    
    is_process_infected = process_check.scan_process()
    
    if is_process_infected:
        detections += 1

    print("\n[+] Launching File Integrity Scan (Module: Ayoub)...")
    time.sleep(1)
    
    is_file_infected = file_check.scan_files()
    
    if is_file_infected:
        detections += 1

    print("\n[+] Launching Network Integrity Scan (Module: Ali)...")
    time.sleep(1)

    is_file_infected = net_check.scan_net()
    
    if is_file_infected:
        detections += 1

    print("\n========================================")
    print("             FINAL REPORT               ")
    print("========================================")
    
    if detections == 0:
        print(" SYSTEM STATUS: CLEAN")
        print(" No anomalies were detected by any module.")
    else:
        print(f"SYSTEM STATUS: INFECTED")
        print(f"Detections found: {detections}")
        print(" Immediate action recommended!")

if __name__ == "__main__":
    run_full_scan()