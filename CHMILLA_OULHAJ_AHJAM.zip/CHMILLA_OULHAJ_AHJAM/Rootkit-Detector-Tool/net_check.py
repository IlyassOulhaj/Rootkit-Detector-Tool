import os
from typing import List

def hex_to_decimal_port(hex_port: str) -> int:
    try:
        return int(hex_port, 16)
    except ValueError:
        return 0

def scan_net(suspicious_port_list: List[int] = None) -> bool:
    print("Running Network Scan (Reading /proc/net/tcp)...")
    
    if suspicious_port_list is None:
        suspicious_port_list = [4444]

    net_file_path = "/proc/net/tcp"
    
    if not os.path.exists(net_file_path):
        print(f"   [Error] File not found: {net_file_path}. Cannot complete network scan.")
        return False

    suspicious_ports_found = []
    
    try:
        with open(net_file_path, 'r') as f:
            lines = f.readlines()[1:] 
            
            for line in lines:
                fields = line.strip().split()
                
                if len(fields) < 4:
                    continue
                
                local_addr_port = fields[1]
                state = fields[3]
                
                if ':' in local_addr_port:
                    _, hex_port_str = local_addr_port.split(':')
                    decimal_port = hex_to_decimal_port(hex_port_str)
                    
                    if state == '0A': 
                        if decimal_port in suspicious_port_list:
                            suspicious_ports_found.append(decimal_port)
                            print(f"   [Suspicious Port] Port {decimal_port} (0x{hex_port_str}) is LISTENING.")

        if suspicious_ports_found:
            return True
        else:
            print("   [RESULT] Ali found no suspicious listening ports.")
            return False

    except Exception as e:
        print(f"   [Fatal Error] An exception occurred during network scan: {e}")
        return False